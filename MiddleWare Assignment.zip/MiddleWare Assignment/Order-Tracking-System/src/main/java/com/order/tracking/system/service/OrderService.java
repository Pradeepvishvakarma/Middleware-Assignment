package com.order.tracking.system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.order.tracking.system.model.Order;
import com.order.tracking.system.repository.OrderRepository;
import com.order.tracking.system.service.event.OrderEvent;

@Service
public class OrderService {
	@Autowired
	private KafkaTemplate<String, OrderEvent> kafkaTemplate;

	@Autowired
	private OrderRepository orderRepository;

	public void placeOrder(Order order) {
        orderRepository.save(order);
        OrderEvent event = new OrderEvent(order.getId(), order.getProduct(), order.getQuantity());
        System.out.println("Sending OrderEvent: " + event); // Log the event being sent
        kafkaTemplate.send("order-placed", event);
    }
}
