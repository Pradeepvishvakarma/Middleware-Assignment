package com.order.tracking.system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderTrackingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
